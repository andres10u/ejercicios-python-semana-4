#Actividad 13: Clasificar y contabilizar números según su tipo

numeros = [12, 7, 4, 9, 16, 3, 20, 5, 8, 11]
cantidad_pares = 0
cantidad_impares = 0

for numero in numeros:
    if numero % 2 == 0:
        cantidad_pares += 1
    else:
        cantidad_impares += 1

print(f"Total de números pares: {cantidad_pares}")
print(f"Total de números impares: {cantidad_impares}")