# Actividad 4: Obtener los valores pares de una secuencia

for i in range(2, 13, 2):
    print(i)