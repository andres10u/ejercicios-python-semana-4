# Actividad 7: Mostrar las letras de una palabra por separado

palabra = "borrador"
for letra in palabra:
    print(letra)




