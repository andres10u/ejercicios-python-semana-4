# Actividad 10: Calcular la cantidad de vocales presentes en un texto

texto = "el futbol es un deporte emocionante"
lista_vocales = "aeiouAEIOU"
total_vocales = 0

for letra in texto:
    if letra in lista_vocales:
        total_vocales += 1

print(f"El texto tiene un total de {total_vocales} vocales.")