# Actividad 11: Encontrar un valor dentro de una lista

lista_numeros = [6, 2, 5, 1, 7, 9, 4]

for valor in lista_numeros:
    if valor == 7:
        print("Se encontró el número solicitado.")
        break
    print(f"Revisando el valor: {valor}")