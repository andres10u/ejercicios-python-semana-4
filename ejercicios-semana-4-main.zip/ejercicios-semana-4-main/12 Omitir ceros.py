# Actividad 12: Saltar los elementos que tengan valor cero
valores = [9, 0, 15, 4, 0, 7, 0, 11]

for numero in valores:
    if numero == 0:
        continue
    print("Número válido:", numero)