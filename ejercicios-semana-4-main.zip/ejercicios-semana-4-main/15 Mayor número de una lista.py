# Actividad 15: Encontrar el valor más alto de un conjunto de números

numeros = [25, 68, 12, 84, 39, 57]
numero_mayor = numeros[0]

for elemento in numeros:
    if elemento > numero_mayor:
        numero_mayor = elemento

print("El valor máximo encontrado es:", numero_mayor)