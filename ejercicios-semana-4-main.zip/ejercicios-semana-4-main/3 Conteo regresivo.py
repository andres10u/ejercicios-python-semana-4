# Actividad 3: Mostrar los números en orden descendente

for i in range(5, 0, -1):
    print(i)