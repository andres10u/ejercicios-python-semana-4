# Actividad 2: Mostrar una serie de números en orden creciente

for i in range(1, 11):
    print(i)