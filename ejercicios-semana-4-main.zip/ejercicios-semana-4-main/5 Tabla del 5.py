# Actividad 5: Calcular los productos de la tabla de multiplicar

for i in range(1, 11):
    print(f"5 x {i} = {5 * i}")