# Actividad 8: Imprimir los nombres de varias frutas

lista_frutas = ["Pera", "Mango", "Uvas", "Piña"]

for alimento in lista_frutas:
    print("Fruta seleccionada:", alimento)