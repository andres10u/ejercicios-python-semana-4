# Ejercicio 1: Repetir un mensaje de bienvenida

for _ in range(5):
    print("Buenos días, bienvenido")