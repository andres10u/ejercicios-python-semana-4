# Actividad 14: Obtener el factorial de un valor entero

numero = 5
resultado = 1

for elemento in range(1, numero + 1):
    resultado *= elemento

print(f"El resultado del factorial de {numero} es {resultado}")