# Actividad 6: Sumar los números de una secuencia

total = 0

for numero in range(1, 11):
    total += numero

print("El resultado de la suma es:", total)