# Actividad 9: Mostrar las calificaciones que cumplen con el mínimo requerido

calificaciones = [3.5, 2.4, 4.2, 2.0, 5.0, 3.7, 2.8]

print("Estudiantes con nota aprobatoria:")

for valor in calificaciones:
    if valor >= 3.0:
        print("Nota:", valor)